
<?php
$conn = mysqli_connect("localhost", "root", "", "calon_mhs");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
